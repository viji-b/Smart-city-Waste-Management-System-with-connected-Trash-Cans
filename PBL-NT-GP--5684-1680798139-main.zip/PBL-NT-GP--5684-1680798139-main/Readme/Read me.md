# smart city waste management system connected with trash cans
demo link  https://youtu.be/8Ocbvda-r1E

